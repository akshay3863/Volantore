// ----------------------------------------------------------------------

export default function Container(theme) {
    return {
        MuiContainer: {
            styleOverrides: {
                maxWidthXxl: {
                    padding: "30px 33px 0 !important",
                },
            }
        },
    };
}
