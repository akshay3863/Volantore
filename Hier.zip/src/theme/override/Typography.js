// ----------------------------------------------------------------------

export default function Typography(theme) {
  return {
    MuiTypography: {
      root: {
        fontFamily: "Product Sans"
      },
      p:{
        fontFamily: "Product Sans"
      }
    }
  };
}


// ----------------------------------------------------------------------
