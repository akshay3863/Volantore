import { createBrowserHistory as createHistory } from 'history';
const history = createHistory();
export default history;
